# Reaction Lab Continuous V1 — entrega para `/home/multiservices-1m`

Distribución consolidada de los **mismos 4 módulos y 2 tests** del ZIP corregido que pasaron el preflight del 12/10/2026. Agrega auditorías y configuración PM2; **no modifica la lógica validada**.

## Contenido y rutas

- `reaction_lab_continuous_scanner.py`: scanner independiente, REACTION 15m 3x3 causal; cada Event ID en `reports/reaction_lab/scanner_events_v1.sqlite3`.
- `reaction_lab_auto_paths.py`: Paths 1m para todas las REACTIONs persistidas V1 RAW, V1 LONG/SHORT y V2 + scanner; SQLite `reports/reaction_lab/auto_paths_v1.sqlite3`.
- `reaction_lab_scan_bridge.py`: lector para Streamlit; solo entra en juego cuando se aplique el instalador.
- `install_reaction_lab_bridge.py`: modifica puntualmente `dashboard/app.py`, crea backup antes de escribir; `--check` para revisar diff.
- `test_reaction_lab_continuous.py`, `test_reaction_lab_auto_paths.py`: 12 tests.
- `reaction_lab_pm2.config.cjs`: configuración para ambos servicios.
- `reaction_lab_final_preflight.py` y `reaction_lab_verify_existing_preflight.py`: auditorías opcionales (la primera crea DBs aisladas).
- `reaction_lab_app_bridge_review.patch` y `README_reaction_lab_continuous_full.md`: referencia y detalles técnicos.

**NO incluye `dashboard/app.py`, CSV de monitores, `*.pkl`, SQLite, `*.env`, claves, outputs históricos, ni ejecutables de trading.** No borra nada existente.

## 1. Instalar los archivos del paquete en la raíz del proyecto

Subir `reaction_lab_continuous_activation_v1.zip` a `/home/multiservices-1m/` y ejecutar:

```bash
cd /home/multiservices-1m
unzip -l reaction_lab_continuous_activation_v1.zip
# Confirmar que NO incluye dashboard/app.py, monitores ni SQLite.
unzip -o reaction_lab_continuous_activation_v1.zip
python3 -m py_compile reaction_lab_continuous_scanner.py reaction_lab_auto_paths.py reaction_lab_scan_bridge.py install_reaction_lab_bridge.py
python3 -m unittest -v test_reaction_lab_continuous.py test_reaction_lab_auto_paths.py
python3 reaction_lab_continuous_scanner.py --project /home/multiservices-1m --check
python3 reaction_lab_auto_paths.py --project /home/multiservices-1m --check
python3 install_reaction_lab_bridge.py --project /home/multiservices-1m --check
```

No usar `--apply` si cambió inesperadamente `app.py`, si no pasan los tests, o si el preview de integración no coincide con las funciones actuales. El resultado previsto del fix debe contener:

```python
return merge_auto_paths(legacy, BASE_DIR, candidate_rows)
return merge_auto_paths(legacy, BASE_DIR, reaction_rows)
return merge_auto_paths(legacy, BASE_DIR, candidate_rows)
```

## 2. Activar solamente captura continua (sin tocar Streamlit)

**Antes** revisar `pm2 list` y `pgrep -af 'reaction_lab_continuous_scanner.py|reaction_lab_auto_paths.py'`. Si alguno ya corre, **no crear procesos duplicados**.

```bash
cd /home/multiservices-1m
pm2 list
pgrep -af 'reaction_lab_continuous_scanner.py|reaction_lab_auto_paths.py' || true
pm2 start reaction_lab_pm2.config.cjs
pm2 list
pm2 logs reaction-lab-scanner --lines 20 --nostream
pm2 logs reaction-lab-auto-paths --lines 20 --nostream
python3 reaction_lab_continuous_scanner.py --db reports/reaction_lab/scanner_events_v1.sqlite3 --status
python3 reaction_lab_auto_paths.py --db reports/reaction_lab/auto_paths_v1.sqlite3 --status
```

**Cuidado:** scanner ~47s por ciclo / cadencia 60s: vigilar retrasos y cobertura. Si PM2 no registra datos, detener ambos en vez de afirmar que hay cobertura garantizada. Los primeros eventos del scanner pueden tener `RECOVERED_WINDOW`; separar esa procedencia del cohorte prospectivo. El primer colector lee los monitores históricos y probablemente marque miles `STALE_BEFORE_COLLECTOR`, lo cual es esperado por retención Redis 400 1m, sin sobrescribir paths previos.

## 3. Integrar el feed y los paths al dashboard (opcional, una vez validados los servicios)

La integración es **otro paso explícito**, porque modifica `dashboard/app.py` y puede recargar Streamlit:

```bash
cd /home/multiservices-1m
python3 install_reaction_lab_bridge.py --project /home/multiservices-1m --check
# SOLO después de revisar el preview:
python3 install_reaction_lab_bridge.py --project /home/multiservices-1m --apply
python3 -m py_compile dashboard/app.py
git diff -- dashboard/app.py
```

El instalador crea `/root/app.py.before_continuous_reactions_<UTC_TIMESTAMP>` (o backup junto a app.py sin acceso a /root). `reaction_lab_scan_bridge.py` debe estar en la raíz del proyecto para que Streamlit lo importe. El feed no recalcula automáticamente los portfolios ni convierte snapshots viejos en nuevos resultados.

## 4. Seguimiento de las primeras 24 horas

```bash
pm2 describe reaction-lab-scanner
pm2 describe reaction-lab-auto-paths
pm2 logs reaction-lab-scanner --lines 30 --nostream
pm2 logs reaction-lab-auto-paths --lines 30 --nostream
cd /home/multiservices-1m
python3 reaction_lab_continuous_scanner.py --status
python3 reaction_lab_auto_paths.py --status
```

Revisar `redis_1m_ok = redis_15m_ok = 290`, scanner <60s, crecimiento de `new_events`, `saved_bars`, ausencia de `MISSING_ENTRY`/`GAP_EXPIRED`; comparar después el período prospectivo contra replay independiente. La prueba de tres ciclos obtuvo PASS_WITH_WARNINGS, no garantiza todavía 100% de recall continuo.

## Deshacer

Detener los procesos creados (no afecta otros PM2):

```bash
pm2 stop reaction-lab-scanner reaction-lab-auto-paths
```

Si se aplicó el bridge, restaurar **únicamente el backup creado en la misma instalación**, verificando su timestamp:

```bash
ls -lt /root/app.py.before_continuous_reactions_*
# cp -a /root/app.py.before_continuous_reactions_<UTC_TIMESTAMP> /home/multiservices-1m/dashboard/app.py
```

No borrar las SQLite como parte de un rollback rutinario: son evidencia de investigación; los servicios no ejecutan órdenes. `pm2 save` solo después de revisar el estado completo de PM2 y decidir persistir estos procesos tras reinicio.

**Commit sugerido:** `feat(reaction-lab): persist continuous causal reactions and 1m paths`
